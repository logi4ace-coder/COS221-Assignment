 

async function fetchRecommendations() {
  const apiKey = localStorage.getItem('api_key');
  if (!apiKey) {
    console.error('No API key found in local storage');
    return;
  }

  try {
    const response = await fetch('/Assignment/api.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'handleGetRecommendations',
        api_key: apiKey
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.status === 'success') {
      displayRecommendations(data.data);
    } else {
      console.error('API Error:', data.message);
    }
  } catch (error) {
    console.error('Error fetching recommendations:', error);
  }
}


function displayRecommendations(products) {
  const recommendationsSection = document.getElementById('recommendations');
  const productGrid = recommendationsSection.querySelector('.product-grid');
  

  productGrid.innerHTML = '';


  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    

    const imageUrl = product.ImageURL || `https://via.placeholder.com/280x160?text=${encodeURIComponent(product.Name)}`;
    
    productCard.innerHTML = `
      <img src="${imageUrl}" class="product-image" alt="${product.Name}">
      <div class="product-name">${product.Name}</div>
      <div class="product-meta">${product.Brand || 'No brand specified'}</div>
      <div class="product-meta">Color: ${product.Color || 'N/A'}</div>
      <div class="product-meta">Material: ${product.Material || 'N/A'}</div>
      ${product.Rating ? `<div class="product-meta">Rating: ${product.Rating}/5</div>` : ''}
      <div class="product-meta">${product.Description || ''}</div>
      <button  class="track-btn" data-product-id="${product.ProductID}">View</button>
    `;
    
    productGrid.appendChild(productCard);
  });

  // Add event listeners to track buttons
  document.querySelectorAll('.track-btn').forEach(button => {
    button.addEventListener('click', function() {
      const productId = this.getAttribute('data-product-id');
      trackProduct(productId);
    });
  });
}

// Function to handle product tracking


// Call fetchRecommendations when the recommendations tab is clicked
document.querySelector('[data-tab="recommendations"]').addEventListener('click', fetchRecommendations);

// Add this to your existing tab switching code
const tabs = document.querySelectorAll('nav button');
tabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    // ... your existing tab switching code ...
    
    // If recommendations tab is clicked, fetch recommendations
    if (tab.getAttribute('data-tab') === 'recommendations') {
      fetchRecommendations();
    }
  });
});


  // Dark mode toggle
  const themeToggle = document.getElementById('themeToggle');
  const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');

  function setTheme(theme) {
    if (theme === 'system') {
      theme = prefersDarkScheme.matches ? 'dark' : 'light';
    }
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    updateButtonText();
  }

  const currentTheme = localStorage.getItem('theme') || 'light';
  setTheme(currentTheme);

  themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
  });

  function updateButtonText() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    themeToggle.textContent = currentTheme === 'dark' ? 'Toggle Light Mode' : 'Toggle Dark Mode';
  }
