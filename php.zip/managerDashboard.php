
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manager Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include "header.php"; ?>
<main>
  <div>

    <div>
      <h1>Welcome back, Manager!</h1>
      <div>
        Company: <span id="businessName">Name-</span>
      </div>
      <button onclick="logout()">Log Out</button>
    </div>

    <!-- Navigation -->
    <div>
      <button onclick="showSection('productManagement')">Products</button>
      <button onclick="showSection('priceAlerts')">Price Alerts</button>
      <button onclick="showSection('analytics')">Analytics</button>
      <button onclick="showSection('profileInfo')">Profile Info</button>
    </div>

    <!-- Product Management -->
    <div id="productManagement">
      <h2>All Products</h2>
      <div id="productList">

    </div>

      <!-- Add Product Form -->
      <h3>Add New Product</h3>
      <form id="productForm" method="POST" action="/Assignment/api.php">
  <div>
    <label for="productName">Name*</label>
    <input type="text" id="productName" name="Name" required />
  </div>

  <div>
    <label for="brand">Brand*</label>
    <input type="text" id="brand" name="Brand" required />
  </div>

  <div>
    <label for="material">Material*</label>
    <input type="text" id="material" name="Material" required />
  </div>

  <div>
    <label for="description">Description*</label>
    <textarea id="description" name="Description" required></textarea>
  </div>

  <div>
    <label for="color">Color*</label>
    <input type="text" id="color" name="Color" value="Unknown" required />
  </div>

  <div>
    <label for="price">Price (R)*</label>
    <input type="number" id="price" name="Price" min="0" step="0.01" required />
  </div>

  <div>
    <label for="imageURL">Product Image URL</label>
    <input type="url" id="imageURL" name="ImageURL" />
  </div>

  <div>
    <label for="tags">Tags (comma separated)</label>
    <input type="text" id="tags" name="Tags" />
  </div>

  <button type="submit">Add Product</button>
</form>
    </div>

    <!-- Price Alerts -->
    <div id="priceAlerts" style="display:none">
      <h2>Price Alerts</h2>
      <div id="alertsList">

      </div>
      <div>
        <button id="notify">Notify Customers</button>
      </div>
    </div>

    <!-- Analytics -->
    <div id="analytics" style="display:none">
      <h2>Business Analytics</h2>
      <canvas id="clicksChart" width="600" height="300"></canvas>
    </div>

    <!-- Profile Info -->
    <div id="profileInfo" style="display:none">
      <h2>Profile Information</h2>
      <p><strong>Email:</strong> <span id="managerEmail">manager@example.com</span></p>
      <p><strong>User Role:</strong> <span id="managerRole">Admin</span></p>
      

      <h3>Update Business Information</h3>
      <form id="businessForm">
        <div>
          <label for="newBusinessName">Business Name</label>
          <input type="text" id="newBusinessName" required />
        </div>
        <button type="submit">Update Business Name</button>
      </form>
      

      <h3>Change Password</h3>
      <form id="passwordForm">
        
        <div>
          <label for="newPassword">New Password</label>
          <input type="password" id="newPassword" required />
        </div>
        <div>
          <label for="confirmPassword">Confirm Password</label>
          <input type="password" id="confirmPassword" required />
        </div>
        <button type="submit">Change Password</button>
      </form>
      
      <button onclick="deleteAccount()">Delete Account</button>
    </div>
  </div>
</main>

<?php include "footer.php"; ?>

<script>
function showSection(id) {
  document.querySelectorAll('[id="productManagement"], [id="priceAlerts"], [id="analytics"], [id="profileInfo"]').forEach(sec => {
    sec.style.display = 'none';
  });
  document.getElementById(id).style.display = 'block';
}

document.addEventListener("DOMContentLoaded", () => {
  const ctx = document.getElementById("clicksChart").getContext("2d");

  // Placeholder chart
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Business A'],
      datasets: [{
        label: 'Clicks',
        data: [45],
        backgroundColor: 'rgba(75, 192, 192, 0.6)'
      }]
    },
    options: { scales: { y: { beginAtZero: true } } }
  });
  
  // Show product management by default
  showSection('productManagement');
});

function logout() {
  // a redirect to logput.php
}

function deleteAccount() {
  // cann he DElete endpoint
}
</script>
<script>
  <?php if (isset($_SESSION['api_key'])): ?>
    localStorage.setItem('api_key', '<?php echo addslashes($_SESSION['api_key']); ?>');
  <?php endif; ?>

  <?php if (isset($_SESSION['user_role'])): ?>
    localStorage.setItem('user_role', '<?php echo addslashes($_SESSION['user_role']); ?>');
  <?php endif; ?>

  <?php if (isset($_SESSION['user_email'])): ?>
    localStorage.setItem('user_email', '<?php echo addslashes($_SESSION['user_email']); ?>');
  <?php endif; ?>
</script>

</body>
</html>