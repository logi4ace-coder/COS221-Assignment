<?php
session_start();


$_SESSION = array();


if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}


session_destroy();
unset($_SESSION);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging out</title>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
</head>
<body>
    <div id="loader" class="loader">
        <img src="images/loading.gif" alt="Loading...">
    </div>
    
    <?php include("footer.php"); ?>
    
    <script>

        localStorage.removeItem('api_key');
        localStorage.removeItem('theme');
        sessionStorage.clear();
        
        console.log("Removed api_key. Current value:", localStorage.getItem('api_key'));
        setTimeout(() => {
    window.location.href = 'index.php?logout=true';
  }, 50);    
  </script>
</body>
</html>


