<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';
require_once '../../../Assignment/configs/email_credentials.php';

$mail = new PHPMailer(true);

try {
    // SMTP settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = EMAIL_USERNAME;
$mail->Password = EMAIL_PASSWORD; // App password, NOT Gmail password
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    // Email headers
    $mail->setFrom(EMAIL_USERNAME, 'CompareXit Alerts');
    $mail->addAddress('zelamene897@gmail.com'); // replace with your test email

    $mail->isHTML(true);
    $mail->Subject = '📢 Test Email from CompareXit';
    $mail->Body    = '
        <html>
            <body>
                <h2 style="color: green;">Success!</h2>
                <p>This is a test email to verify PHPMailer setup.</p>
            </body>
        </html>
    ';

    $mail->send();
    echo "✅ Email sent successfully.";
} catch (Exception $e) {
    echo "❌ Email failed: {$mail->ErrorInfo}";
}
